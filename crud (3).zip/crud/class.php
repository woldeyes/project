<?php
	require 'config.php';
	require 'IRepository.php';
	class db_class extends db_connect implements IRepository{	
		
		public function __construct(){
			$this->connect();
		}
		
		public function dbConnect(){
			
				$this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
				if(!$this->conn){
					$this->error = "Fatal Error: Can't connect to database" . $this->connect->connect_error();
					return false;
				}
			
		}
		public function create($firstname, $lastname){
			$stmt = $this->conn->prepare("INSERT INTO `member` (`firstname`, `lastname`) VALUES (?, ?)") 
			or die($this->conn->error);
			$stmt->bind_param("ss", $firstname, $lastname);
			if($stmt->execute()){
				$stmt->close();
				$this->conn->close();
				return true;
			}
		}
		
		public function read(){
			$stmt = $this->conn->prepare("SELECT * FROM `member` ORDER BY `lastname` ASC") 
			or die($this->conn->error);
			if($stmt->execute()){
				$result = $stmt->get_result();
				$stmt->close();
				$this->conn->close();
				return $result;
			}
		}
		
		public function member_id($mem_id){
			$stmt = $this->conn->prepare("SELECT * FROM `member` WHERE `mem_id` = '$mem_id'") 
			or die($this->conn->error);
			if($stmt->execute()){
				$result = $stmt->get_result();
				$fetch = $result->fetch_array();
				$stmt->close();
				$this->conn->close();
				return $fetch;
			}
		}
		
		public function delete($mem_id){
			$stmt = $this->conn->prepare("DELETE FROM `member` WHERE `mem_id` = '$mem_id'") 
			or die($this->conn->error);
			if($stmt->execute()){
				$stmt->close();
				$this->conn->close();
				return true;
			}
		}
		
		public function update($firstname, $lastname, $mem_id){
			$stmt = $this->conn->prepare("UPDATE `member` SET `firstname` = '$firstname', `lastname` = '$lastname' WHERE `mem_id` = '$mem_id'") or die($this->conn->error);
			if($stmt->execute()){
				$stmt->close();
				$this->conn->close();
				return true;
			}
		}
 	}	
?>