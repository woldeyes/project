<?php
require_once 'MySqlRepository.php';
$db = new MysqlRepo('localhost','root','','crud'); 
//$db = new MSSqlRepo('DESKTOP-N8EVIES\SQLEXPRESS','root','','crud'); 


$db->dbConnect();
$data ="Insert this data ";
$firstName ="Ayelu";
$lastName ="Akelilu";
//$db->insert($firstName,$lastName);
//$db->read(5);
$db->delete(3);
//$db->update($firstName,$lastName,5);
?>
