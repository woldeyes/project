<?php
interface IRepository
{
    public function dbConnect();
    public function create($firstname, $lastname);
    public function read();
    public function update($firstname, $lastname, $mem_id);
    public function delete($mem_id);
}
?>
