<?php
define('db_host', 'localhost');
define('db_user', 'root');
define('db_pass', '');
define('db_name', 'crud');
require_once 'Interfaces.php';
require_once 'abstract.php';
class MysqlRepo extends DBConnection implements IRepository{
        public $host = db_host;
		public $user = db_user;
		public $pass = db_pass;
		public $dbname = db_name;
		public $conn;
		public $error;
		
 public function __construct($host,$uid,$db,$pass)
{
   parent::__construct($host,$uid,$db,$pass);
}
public function dbConnect()
{
    $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
    if(!$this->conn){
        $this->error = "Fatal Error: Can't connect to database" . $this->connect->connect_error();
        return false;
    }
}
public function delete($where)
{  
    
    $stmt = $this->conn->prepare("DELETE FROM `member` WHERE `mem_id` = '$where'") or die($this->conn->error);
   if($stmt->execute()){
       $stmt->close();
       $this->conn->close();
       return "Deleted";
   }
}
public function insert($firstName,$lastName)
{
    $stmt = $this->conn->prepare("INSERT INTO `member` (`firstname`, `lastname`)
                                   VALUES (?, ?)") 
			or die($this->conn->error);
			$stmt->bind_param("ss", $firstName, $lastName);
			if($stmt->execute()){
				$stmt->close();
				$this->conn->close();
				return true;
}}
public function read($where)
{
    $stmt = $this->conn->prepare("SELECT * FROM `member` WHERE `mem_id` = '$where'") 
    or die($this->conn->error);
    if($stmt->execute()){
        $result = $stmt->get_result();
        $fetch = $result->fetch_array();
        $stmt->close();
        $this->conn->close();
        print_r($fetch);
    }
}
public function update($firstName,$lastName,$where)
{
    $stmt = $this->conn->prepare("UPDATE `member` SET `firstname` = '$firstName',
     `lastname` = '$lastName' 
     WHERE `mem_id` = '$where'") or die($this->conn->error);
    if($stmt->execute()){
        $stmt->close();
        $this->conn->close();
        return "Updated";
    }
}
}

?>

