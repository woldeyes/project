<?php
interface IRepository
{
    public function dbConnect();
    public function insert($firstName,$lastName);
    public function read($where);
    public function update($firstName,$lastName,$where);
    public function delete($where);
}
?>
